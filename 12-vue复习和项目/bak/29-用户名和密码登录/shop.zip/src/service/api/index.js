import ajax from './ajax'

// 把axios进行封装的目录，获取数据，就像调用一个方法一个来获取  配置了cors
export const getHomeData = ()=>ajax("http://localhost:3000/data");
export const getCategories = ()=>ajax("http://localhost:3000/categories");
export const getCategoriesdetail = (params)=>ajax("http://localhost:3000/categoriesdetail"+params);

//  http://localhost:3000/web/xlmc/api/send_code
// const LOCAL_BASE_URL = 'http://localhost:3000/web/xlmc';
const LOCAL_BASE_URL = '/api';

// 2.1 获取短信验证码(GET)
export const getPhoneCode = (phone) => ajax(LOCAL_BASE_URL + '/api/send_code', {phone});
// 2.2 手机验证码登录(POST)
export const phoneCodeLogin = (phone, code) => ajax(LOCAL_BASE_URL + '/api/login_code', {phone, code}, 'POST');
// 2.3 用户名和密码登录（POST）
export const pwdLogin = (user_name, user_pwd, captcha) => ajax(LOCAL_BASE_URL + '/api/login_pwd',{user_name, user_pwd, captcha}, 'POST')











