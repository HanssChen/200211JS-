export default{
    shopCart:{},  // 保存购物车的商品
    userInfo: {}  // 保存用户信息
}


/* 
 
  shopCart:{
      "001":{"num":1,"checked":true, "name":goodsName,"small_image":smallImage,"price":goodsPrice},
      "002":{num":1,"checked":true, "name":goodsName,"small_image":smallImage,"price":goodsPrice},
      "003":{num":1,"checked":true, "name":goodsName,"small_image":smallImage,"price":goodsPrice},
      "004":{num":1,"checked":true, "name":goodsName,"small_image":smallImage,"price":goodsPrice}
  }

 */




