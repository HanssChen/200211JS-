function sub(x,y){
    return x-y;
}

module.exports = {
    sub
}
