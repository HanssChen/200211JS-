Page({
  data: {
    counter:0
  },
  // 自定义事件发生时，执行此函数
  onButtonClick(value){
    console.log(value)
    console.log("方法执行了")

    this.setData({
      counter:++this.data.counter
    })
  }
})