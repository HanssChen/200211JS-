Page({
  data: {
    isShow:true
  },
  onTabItemClick(e){
    console.log("onTabItemClick");
    console.log(e.detail)
  },
  onClick(){
    // 获取页面中的组件对象
    let com = this.selectComponent("#counter");
    // console.log(com)
    // com.data.number;

    // 在父中直接修改子中的状态
    // 不好
    // com.setData({
    //   number:++com.data.number
    // })

    // 通过调用子组件中的方法，达到修改状态的目的
    com.increment();
  },
  onRemove(){
    this.setData({
      isShow:!this.data.isShow
    })
  }
})