// components/manyslot/manyslot.js
Component({
  options:{
    multipleSlots:true
  },
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {

  },
  /**
   * 配置组件所在页面的生命周期
   */
  pageLifetimes:{
    show(){
      console.log("组件所在的页面显示出来")
    },
    hide(){
      console.log("组件所在的页面隐藏出来")
    },
    resize(){
      console.log("组件所在的页面大小发生改变了")
    }
  },
  /**
   * 配置组件自身的生命周期
   */
  lifetimes:{
    created(){
      console.log("组件被创建出来会执行")
    },
    attached(){
      console.log("组件被添加到页面上时会执行")
    },
    ready(){
      console.log("组件渲染时会执行")
    },
    detached(){
      console.log("组件被移除时执行")
    }
  }
})
