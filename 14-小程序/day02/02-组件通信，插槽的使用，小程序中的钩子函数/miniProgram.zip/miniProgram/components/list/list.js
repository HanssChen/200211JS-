Component({
  properties: {

  },
  data: {

  },
  methods: {

  }
})
