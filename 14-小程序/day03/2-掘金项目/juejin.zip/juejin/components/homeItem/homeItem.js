Component({
  properties: {
    item: {
      type: Object,
      value: {}
    },
  },
  methods: {
    toHomeDetail(e) {
      let item = e.currentTarget.dataset.item
      let entryId = item.objectId
      // console.log(item, entryId);
      let type = item.type
      let url = `/pages/newsDetail/newsDetail?id=${entryId}&type=${type}`
      wx.navigateTo({
        url
      })
    }
  }
})