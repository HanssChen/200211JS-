App({
  globalData: {
    systeminfo: {},
    config: {
      // 热门推荐
      timelineRequestUrl: 'https://timeline-merger-ms.juejin.im/v1',
      entryViewStorageApiMsRequestUrl: 'https://entry-view-storage-api-ms.juejin.im/v1',
      // 我的
      apiRequestUrl: 'https://user-storage-api-ms.juejin.im/v1',
      notifyRequestUrl: 'https://ufp-api-ms.juejin.im/v1',
      goldTagMsRequestUrl: 'https://gold-tag-ms.juejin.im/v1',
      // 登录相关
      loginRequestUrlByMobile: 'https://juejin.im/auth/type/phoneNumber',
      loginRequestUrlByEMail: 'https://juejin.im/auth/type/email',
      // 动态相关
      shortMsgMsRequestUrl: 'https://short-msg-ms.juejin.im/v1',
    }
  },  
  onLaunch() {
    wx.getSystemInfo({
      success: (res) => {
        console.log(res);
        this.globalData.systeminfo = res
      },
    })
  },
})

// https://timeline-merger-ms.juejin.im/v1/get_entry_by_timeline?src=web&limit=40&category=all&recomment=1
