const WxParse = require('./../../wxParse/wxParse.js')
const config = getApp().globalData.config

Page({
  data: {
    postInfo: {}, // 详情数据
    type: '', // 类型
  },

  onLoad: function (options) {
    console.log(options);
    // 1. 处理数据
    let type = options.type
    let id = options.id
    this.setData({
      type
    });

    // 2. 获取网络数据
    this.getArticleById(id);
    this.getArticleDetail(id);
  },

  // 获取文章摘要
  getArticleById(articleId){
    wx.request({
      url: `${config.timelineRequestUrl}/get_entry_by_ids`,
      data: {
        src: 'web',
        entryIds: articleId,
      },
      success: (res) => {
        let data = res.data
        console.log(data);
        if (data.s === 1) {
          let entrylist = (data.d && data.d.entrylist) || []
          this.setData({
            postInfo: entrylist[0] || {},
          })
          wx.setNavigationBarTitle({
            title: (entrylist[0].user && entrylist[0].user.username) || '掘金'
          })
        } else {
          wx.showToast({
            title: data.m.toString(),
            icon: 'none',
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '网络出现问题，请稍后再试',
          icon: 'none',
        })
      },
    })
  }, 

  // 获取文章详情
  getArticleDetail(articleId){
    wx.request({
      url: `${config.entryViewStorageApiMsRequestUrl}/getEntryView`,
      data: {
        src: 'web',
        entryId: articleId,
      },
      success: (res) => {
        let data = res.data
        console.log(data);
        if (data.s === 1) {
          let article = (data.d && data.d.content) || ''
          WxParse.wxParse('article', 'html', article, this)
        } else {
          wx.showToast({
            title: data.m.toString(),
            icon: 'none',
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '网络出现问题，请稍后再试',
          icon: 'none',
        })
      },
    });
  }

})