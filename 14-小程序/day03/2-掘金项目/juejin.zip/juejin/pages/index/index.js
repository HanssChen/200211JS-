// 1. 获取全局配置
const config = getApp().globalData.config
// 2. 获取工具类
const utils = require('./../../utils/util.js')

Page({
  data: {
    COUNT: 20,
    // 推荐消息
    timeline: []
  },

  onShow: function (options) {
    // 当页面没有数据的时候加载
    if (this.data.timeline.length === 0){
      wx.startPullDownRefresh({})
    }
  },

  onPullDownRefresh() {
    this.init()
  },

  // 上拉加载
  onReachBottom() {
    this.getEntryByTimeline()
  },

  init(){
    this.getEntryByTimeline(true);
  },
  
  // 获取推荐列表数据
  getEntryByTimeline(reload) {
    let timeline = this.data.timeline
    if (utils.isEmptyObject(timeline) || reload) {
      timeline = [{ verifyCreatedAt: '' }]
    }
    let rankIndex = (timeline.slice(-1)[0].verifyCreatedAt) || ''
    console.log(rankIndex);
    // 展示加载动画
    wx.showLoading({
      title: '正在加载数据……'
    })
    wx.request({
      url: `${config.timelineRequestUrl}/get_entry_by_timeline`,
      data: {
        src: 'web',
        limit: this.data.COUNT,
        category: 'all',
        recomment: 1,
        before: rankIndex
      },
      success: (res) => {
        let data = res.data
        console.log(res.data);
        if (data.s === 1 && data.m === 'ok') {
          wx.hideLoading();
          let list = (data.d && data.d.entrylist) || []
          this.setData({
            timeline: reload ? list : this.data.timeline.concat(list)
          })
        } else {
          wx.showToast({
            title: data.m.toString(),
            icon: 'none',
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '网络出现问题，请稍后再试',
          icon: 'none',
        })
      },
      complete: () => {
        // 停止下拉
        wx.stopPullDownRefresh()
      }
    })
  },
})