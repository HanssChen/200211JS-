const utils = require('./../../utils/util.js')
const config = getApp().globalData.config

Page({
  data: {
    userInfo: {}, // 用户信息
    userNotificationNum: 0, // 通知数量
    auth: {} // 登录信息
  },

  onShow() {
    // 1. 获取本地的用户信息 
    let auth = utils.isLogined();
    this.setData({
      auth,
    })

    // 2. 如果用户已经登录
    if (auth) {
      this.getUserInfo()
      this.userNotificationNum()
    } else {
      this.setData({
        userInfo: {},
        userNotificationNum: 0,
      })
    }
  },

  // 3. 获取用户信息
  getUserInfo() {
    const auth = this.data.auth
    wx.request({
      url: `${config.apiRequestUrl}/getUserInfo`,
      data: {
        src: 'web',
        device_id: auth.clientId,
        uid: auth.uid,
        token: auth.token,
        current_uid: auth.uid,
      },
      success: (res) => {
        let data = res.data
        if (data.s === 1) {
          this.setData({
            userInfo: data.d,
          })
        } else {
          wx.showToast({
            title: data.m.toString(),
            icon: 'none',
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '网络出现问题，请稍后再试',
          icon: 'none',
        })
      },
    })
  },

  // 消息中心消息条数
  userNotificationNum() {
    const auth = this.data.auth
    wx.request({
      url: `${config.notifyRequestUrl}/getUserNotificationNum`,
      data: {
        src: 'web',
        uid: auth.uid,
        token: auth.token,
      },
      success: (res) => {
        let data = res.data
        if (data.s === 1) {
          this.setData({
            userNotificationNum: data.d && data.d.notification_num,
          })
        } else {
          wx.showToast({
            title: data.m.toString(),
            icon: 'none',
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '网络出现问题，请稍后再试',
          icon: 'none',
        })
      },
    })
  },

  navigatItem(e) {
    console.log('点击了');
    const url = e.currentTarget.dataset.url || '/pages/index/index'
    const toUrl = () => {
      wx.navigateTo({
        url,
      })
    }
    if (utils.isLogined()) {
      toUrl()
    } else {
      wx.navigateTo({
        url: '/pages/login/login'
      })
    }
  }
})