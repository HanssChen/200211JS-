const config = getApp().globalData.config
const utils = require('./../../utils/util.js')

Page({
  data: {
    COUNT: 30,
    swiperHeight: 'auto',
    recommendList: [],
    list: [],
    auth: {},
    scrollTop: 0,
    after: ''
  },
  onShow: function (options) {
    // 当页面没有数据的时候加载
    if (this.data.list.length === 0 || !this.data.scrollTop) {
      wx.startPullDownRefresh({})
    }
  },
  onPullDownRefresh() {
    this.init()
  },
  init() {
    this.setData({
      auth: {},
    })
    let auth = utils.isLogined()
    this.setData({
      auth,
    })
    this.initSwiper()
    this.getHotRecommendList()
    this.queryDongtai(true)
  },
  // 初始化swiper
  initSwiper() {
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          swiperHeight: `${(res.windowWidth || res.screenWidth) / 375 * 135}px`
        })
      },
    })
  },
  // 热门推荐列表
  getHotRecommendList() {
    const auth = this.data.auth
    wx.request({
      url: `${config.shortMsgMsRequestUrl}/getHotRecommendList`,
      data: {
        uid: auth.uid,
        device_id: auth.clientId,
        client_id: auth.client_id,
        token: auth.token,
        src: 'web',
      },
      success: (res) => {
        let data = res.data
        console.log('--------------------');
        console.log(data);
        if (data.s === 1) {
          this.setData({
            recommendList: (data.d && data.d.list) || [],
          })
        } else {
          // this.illegalToken(data.s)
          wx.showToast({
            title: data.m.toString(),
            icon: 'none',
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '网络出现问题，请稍后再试！',
          icon: 'none',
        })
      },
    })
  },
  // 沸点列表
  queryDongtai(reload) {
    const auth = this.data.auth
    let list = this.data.list
    if (utils.isEmptyObject(list) || reload) {
      this.setData({
        list: [],
        after: '',
      })
    }
    let after = ''
    wx.request({
      url: `https://web-api.juejin.im/query`,
      header: {
        'X-Agent': 'Juejin/Web',
      },
      method: 'POST',
      data: {
        operationName: '',
        query: "",
        variables: {
          size: 20,
          after: this.data.after,
        },
        extensions: {
          query: {
            id: '964dab26a3f9997283d173b865509890'
          }
        }
      },
      success: (res) => {
        let data = res.data || {}
        data = data.data
        console.log(data)
        if (!utils.isEmptyObject(data)) {
          const items = data.recommendedActivityFeed.items
          this.setData({
            after: (items.pageInfo && items.pageInfo.endCursor) || ''
          })
          const edges = items.edges || []
          this.setData({
            list: this.data.list.concat(edges)
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '网络出现问题，请稍后再试！',
          icon: 'none',
        })
      },
      complete: () => {
        wx.stopPullDownRefresh()
      },
    })
  },
})