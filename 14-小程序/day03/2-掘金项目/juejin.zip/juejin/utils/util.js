// 1. 判断一个对象是否为空
let isEmptyObject = (obj) => {
  for (let i in obj) {
    return false
  }
  return true
}

// 2. 判断是否登录
let isLogined = () => {
  let auth = wx.getStorageSync('auth') || {}
  if (auth.token && auth.uid) {
    return auth
  }
  return false
}

module.exports = {
  isEmptyObject,
  isLogined
}
