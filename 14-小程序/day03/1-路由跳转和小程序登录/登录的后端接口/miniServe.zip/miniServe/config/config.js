module.exports = {
  // db uri
  db: 'mongodb://localhost:27017/mini',
  // Setting port for server
  port: 3000,
  host: 'http://0.0.0.0:3000',
  jwtSecret: 'myjwtsecret',
  appId:'wx8f6aebbed67b3295',
  appSecret:'2f79e2f809af080298a6d0892621ea6d'
}
